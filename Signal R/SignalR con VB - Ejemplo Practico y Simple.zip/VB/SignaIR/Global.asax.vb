﻿
Imports System.Web.SessionState
Imports System.Web.Routing
Imports Microsoft.AspNet.SignalR

Public Class Global_asax
    Inherits HttpApplication

    Sub Application_Start(sender As Object, e As EventArgs)
        'RouteTable.Routes.MapHubs()
        ' Se desencadena al iniciar la aplicación
    End Sub
End Class