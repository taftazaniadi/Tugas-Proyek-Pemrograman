﻿Imports Microsoft.AspNet.SignalR.Hubs

Public Class Notificacion
    Inherits System.Web.UI.Page

End Class