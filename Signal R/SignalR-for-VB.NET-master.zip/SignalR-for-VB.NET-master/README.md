SignalR-for-VB.NET
==================


Bu uygulama ile signalR kullanarak ufak bir chat uygulamasi gelistirdim.

SignalR i projenize Nuget'i kullanarak dahil edebilirisiniz.

Uygulamanin calisan halini <a href="http://signalrforvbnet.azurewebsites.net"> burdan </a> inceleyebilirsiniz.
